
/**
 * 在这里给出对类 Item 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */
public class Item
{
    private int id;
    private String name;
    private String desc;
    private double unitPrice;
    
    public Item(int id, String name, String desc, double unitPrice)
    {
        // initialise instance variables
        this.id = id;
        this.name = name;
        this.desc= desc;
        this.unitPrice = unitPrice;
    }

    public Item()
    {
        id = 0;
        name = "null";
        desc= "null";
        unitPrice = 0;
    }
    
    public void setId(int id)
    {
        this.id = id;
    }
    
    public int getId()
    {
        return id;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setDesc(String desc)
    {
        this.desc = desc;
    }
    
    public String getDesc()
    {
        return desc;
    }
    
    public void setUnitPrice(double unitPrice)
    {
        this.unitPrice = unitPrice;
    }
    
    public double getUnitPrice()
    {
        return unitPrice;
    }
    
    public String toString()
    {
        return "id:" + id + ", name:" + name + ", description:" + desc + ", Unit price:" + unitPrice;
    }
    
}
