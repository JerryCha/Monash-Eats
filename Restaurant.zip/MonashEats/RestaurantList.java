import java.util.ArrayList;
import java.util.Date;
/**
 * 在这里给出对类 RestaurantList 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */
public class RestaurantList
{
    private ArrayList<Restaurant> restaurantList;
    
    public RestaurantList(ArrayList<Restaurant> restaurantList)
    {
        this.restaurantList = restaurantList;
    }

    public RestaurantList()
    {
        restaurantList = new ArrayList<Restaurant>();
    }
    
    public void setRestaurantList(ArrayList<Restaurant> restaurantList)
    {
        this.restaurantList = restaurantList;
    }
    
    public ArrayList<Restaurant> getRestaurantList()
    {
        return restaurantList;
    }
    
    public void getListOfRestaurant(int i)
    {
        restaurantList.get(i);
    }
    
    public void getRestaurant(int id)
    {
        for (int i = 0; i < getRestaurantCount(); i++)
        {
            if (restaurantList.get(i).getId() == id)
            {
                restaurantList.get(i);
            }
        }
    }
    
    public void getRestaurantByName(String name)
    {
        for (int i = 0; i < getRestaurantCount(); i++)
        {           
            if (restaurantList.get(i).getName().equals(name))
            {
                restaurantList.get(i);
            }
        }
    }
    public int getRestaurantCount()
    {
        return restaurantList.size();
    }
    
    public boolean initialize()
    {
        return true;
    }
    
    public boolean save()
    {
        return true;
    }
    
    public boolean addRestaurant(int id, String name, String surburb, String street, String phone, String email, Date openTime, double businessHour, int openDay)
    {
        Restaurant rest = new Restaurant();
        rest.setId(id);
        rest.setName(name);
        rest.setSurburb(surburb);
        rest.setStreet(street);
        rest.setPhone(phone);
        rest.setEmail(email);
        rest.setOpenTime(openTime);
        rest.setBusinessHour(businessHour);
        rest.setOpenDay(openDay);
        System.out.println("Restaurant is successful added");
        return true;
    }
    
    public boolean delRestaurant(int id)
    {
        for (int i = 0; i < getRestaurantCount(); i++)
        {           
            if (restaurantList.get(i).getId() == id)
            {
                restaurantList.remove(i);
            }
        }
        System.out.println("Restaurant" + id + "is removed");
        return true;
    }
    
    public void delRestaurantByName(String name)
    {
        for (int i = 0; i < getRestaurantCount(); i++)
        {           
            if (restaurantList.get(i).getName().equals(name))
            {
                restaurantList.remove(i);
            }
        }
        System.out.println("Restaurant" + name + "is removed");
    }
    
    public void searchResItem()
    {
        Restaurant res = new Restaurant();
        res.displayMenu();
    }
    
    public void editRestaurant(String orName, String edName)
    {
        for (int i = 0; i < getRestaurantCount(); i++)
        {           
            if (restaurantList.get(i).getName().equals(orName))
            {
                restaurantList.get(i).setName(edName);
            }
        }
        System.out.println("Name edit successful");
    }
    
}
