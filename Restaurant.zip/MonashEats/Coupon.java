import java.util.ArrayList;
import java.util.Date;
/**
 * 在这里给出对类 Coupon 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */
public class Coupon
{
    private String couponCode;
    private String couponDesc;
    private Date expireDate;
    private char operator;
    private double value;
    private ArrayList<Integer> appliedItemId;

    public Coupon(String couponCode, String couponDesc, Date expireDate, char operator, double value, ArrayList<Integer> appliedItemId)
    {
        this.couponCode = couponCode;
        this.couponDesc = couponDesc;
        this.expireDate = expireDate;
        this.operator = operator;
        this.value = value;
        this.appliedItemId = appliedItemId;
    }

    public Coupon()
    {
        appliedItemId = new ArrayList<Integer>();
    }

    public void setCouponCode(String couponCode)
    {
        this.couponCode = couponCode;
    }

    public String getCouponCode()
    {
        return couponCode;
    }

    public void setCouponDesc(String couponDesc)
    {
        this.couponDesc = couponDesc;
    }

    public String getCouponDesc()
    {
        return couponDesc;
    }

    public void setExpireDate(Date expireDate)
    {
        this.expireDate = expireDate;
    }

    public Date getExpireDate()
    {
        return expireDate;
    }

    public void setOperator(char operator) 
    {
        this.operator = operator;
    }

    public char getOperator()
    {
        return operator;
    }
    
    public void setValue(double value)
    {
        this.value = value;
    }
    
    public double getValue()
    {
        return value;
    }
    
    public void setAppliedItemId(ArrayList<Integer> appliedItemId)
    {
        this.appliedItemId = appliedItemId;
    }
    
    public ArrayList<Integer> getAppliedItemId()
    {
        return appliedItemId;
    }
    
    public int numberOfItemId()
    {
        return appliedItemId.size();
    }
    
    public void removeItemId(int index)
     {
        appliedItemId.remove(index);
    }

}
