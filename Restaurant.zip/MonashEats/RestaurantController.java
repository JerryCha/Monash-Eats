import java.util.Date;
/**
 * 在这里给出对类 RestaurantController 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */
public class RestaurantController
{
    private RestaurantList restaurantList;
    private OwnerList ownerList;

    public RestaurantController(RestaurantList restaurantList, OwnerList ownerList)
    {
        this.restaurantList = restaurantList;
        this.ownerList = ownerList;
        restaurantList = new RestaurantList();
    }

    public RestaurantController()
    {

    }

    public void setRestaurantList(RestaurantList restaurantList)
    {
        this.restaurantList = restaurantList;
    }

    public RestaurantList getRestaurant()
    {
        return restaurantList;
    }

    public void setOwnerList(OwnerList ownerList)
    {
        this.ownerList = ownerList;
    }

    public OwnerList getOwnerList()
    {
        return ownerList;
    }

    public void listRestaurant()
    {
        for (int i = 0; i < restaurantList.getRestaurantCount(); i++)
        {
            System.out.println("The total number of restaurant is " + restaurantList.getRestaurantCount());
            restaurantList.getListOfRestaurant(i);
        }
    }

    public void searchRestaurantById(int index)
    {
        restaurantList.getRestaurant(index);
    }

    public void searchRestaurantByName(String name)
    {
        restaurantList.getRestaurantByName(name);
    }

    public boolean createRestaurant(int id, String name, String surburb, String street, String phone, String email, Date openTime, double businessHour, int openDay)
    {
        restaurantList.addRestaurant(id, name, surburb, street, phone, email, openTime, businessHour, openDay);
        return true;
    }

    public boolean editRestaurant(String orginalName, String editedName)
    {
        restaurantList.editRestaurant(orginalName, editedName);
        return true;
    }

    public boolean delRestaurant(int id)
    {
        restaurantList.delRestaurant(id);
    }

    public void viewItem()
    {
        restaurantList.searchResItem();
    }

    public boolean isNumeric(String str)
    {
        for (int i = str.length();--i>=0;)
        {  
            if (!Character.isDigit(str.charAt(i)))
            {
                System.out.println("Please enter a number");
                return false;
            }
        }
        return true;
    }
    
    public boolean lengthWithinRange(String str, int max, int min)
    {
        if (min > str.length() || str.length() > max)
        {
            System.out.println("Please enter a information in range of" + min + "and" + max);
            return false;
        }
        return true;
    }
    
    public boolean authorize()
    {
        
    }
    
}
