import java.util.ArrayList;
import java.util.Date;
/**
 * 在这里给出对类 Restaurant 的描述。
 * 
 * @作者（你的名字）
 * @版本（一个版本号或者一个日期）
 */
public class Restaurant
{
    private int id;
    private String name;
    private String surburb;
    private String street;
    private String phone;
    private String email;
    private ArrayList<Coupon> couponList;
    private ArrayList<Item> menu;
    private Date openTime;
    private double businessHour;
    private int openDay;
    
    public Restaurant(int id, String name, String surburb, String street, String phone, String email, ArrayList<Coupon> couponList, ArrayList<Item> menu, Date openTime, double businessHour, int openDay)
    {
        this.id = id;
        this.name = name;
        this.surburb= surburb;
        this.street= street;
        this.phone= phone;
        this.email= email;
        this.couponList= couponList;
        this.menu= menu;
        this.openTime= openTime;
        this.businessHour= businessHour;
        this.openDay = openDay;
    }

    public Restaurant()
    {
        couponList = new ArrayList<Coupon>();
        menu = new ArrayList<Item>();
    }
    
    public void setId(int id)
    {
        this.id = id;
    }
    
    public int getId()
    {
        return id;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    public void setSurburb(String surburb)
    {
        this.surburb= surburb;
    }
    
    public String getSurburb()
    {
        return surburb;
    }
    
    public void setStreet(String street)
    {
        this.street = street;
    }
    
    public String getStreet()
    {
        return street;
    }
    
    public void setPhone(String phone)
    {
        this.phone = phone;
    }
    
    public String getPhone()
    {
        return phone;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    
    public String getEmail()
    {
        return email;
    }
    
    public void setCouponList(ArrayList<Coupon> couponList)
    {
        this.couponList = couponList;
    }
    
    public ArrayList<Coupon> getCouponList()
    {
        return couponList;
    }
    public void setMenu(ArrayList<Item> menu)
    {
        this.menu = menu;
    }
    
    public ArrayList<Item> getMenu()
    {
        return menu;
    }
    
    public void setOpenTime(Date openTime)
    {
        this.openTime = openTime;
    }
    
    public Date getOpenTime()
    {
        return openTime;
    }
    
    public void setBusinessHour(double businessHour)
    {
        this.businessHour = businessHour;
    }
    
    public double getBusinessHour()
    {
        return businessHour;
    }
    
    public void setOpenDay(int openDay)
    {
        this.openDay = openDay;
    }
    
    public int getOpenDay()
    {
        return openDay;
    }
    
    public void addItem(int id, String name, String desc, double unitPrice)
    {
        Item item = new Item();
        item.setId(id);
        item.setName(name);
        item.setDesc(desc);
        item.setUnitPrice(unitPrice);
        menu.add(item);
    }
    
    public boolean hasCoupon()
    {
        //是否有优惠券
        if (couponList.size() == 0)
        {
            System.out.println("Sorry, you don't have any coupons");
            return false;
        }
        else
        {
            System.out.println("You have" + couponList.size() +"coupons are available");
            return true;
        }
    }
    
    public Coupon getCoupon(int index)
    {
        return couponList.get(index);
    }
    
    public Item getItem(int index)
    {
        return menu.get(index);
    }
    
    public void delItem(int index)
    {
        menu.remove(index);
    }
    
    public void addCoupon(String couponCode, String couponDesc, Date expireDate, char operator, double value, ArrayList<Integer> appliedItemId)
    {
        Coupon cp = new Coupon();
        cp.setCouponCode(couponCode);
        cp.setCouponDesc(couponDesc);
        cp.setExpireDate(expireDate);
        cp.setOperator(operator);
        cp.setValue(value);
        couponList.add(cp);
    }
    
    public void displayMenu()
    {
        for(int i = 0; i < menu.size(); i++)
        {
            System.out.println(i + "." + menu.get(i).getId());
            System.out.println("  " + menu.get(i).getName());
            System.out.println("  " + menu.get(i).getDesc());
            System.out.println("  " + menu.get(i).getUnitPrice());
        }
    }
    
    public void menuReady()
    {
        Item i = new Item();
        i.setId(0);
        i.setName("Beef burger");
        i.setDesc("delicious beef and vegetable");
        i.setUnitPrice(15.00);
        menu.add(i);
        Item t = new Item();
        t.setId(1);
        t.setName("pork burger");
        t.setDesc("delicious pork and onions");
        t.setUnitPrice(12.00);
        menu.add(t);
        Item e = new Item();
        e.setId(2);
        e.setName("Baked lamp chop");
        e.setDesc("Delicious roast lamb chop, the highest evaluation");
        e.setUnitPrice(20.00);
        menu.add(e);
        Item m = new Item();
        e.setId(3);
        e.setName("Cappuccino");
        e.setDesc("Classic desserts are coming");
        e.setUnitPrice(10.00);
        menu.add(m);
        Item f = new Item();
        e.setId(4);
        e.setName("Budweiser");
        e.setDesc("It will never be absent at a time of celebration");
        e.setUnitPrice(3.00);
        menu.add(f);
    }
    
}
